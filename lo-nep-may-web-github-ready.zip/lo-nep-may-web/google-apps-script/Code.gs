/**
 * Lò Nếp Mây — nhận đơn hàng từ website và ghi vào sheet "Orders".
 *
 * CÁCH DÙNG:
 * 1. Mở Google Sheet bạn muốn dùng làm database đơn hàng.
 * 2. Vào Tiện ích mở rộng (Extensions) > Apps Script.
 * 3. Xóa nội dung mặc định trong Code.gs, dán toàn bộ nội dung file này vào.
 * 4. (Tùy chọn nhưng khuyến nghị) Đặt một mã bí mật để chặn người lạ gửi rác vào Sheet:
 *    - Vào Project Settings (biểu tượng bánh răng) > Script Properties > Add script property
 *    - Key: ORDER_WEBHOOK_TOKEN, Value: một chuỗi bất kỳ bạn tự nghĩ ra (vd: lnm-2026-xyz)
 * 5. Vào Deploy > New deployment > chọn loại "Web app":
 *    - Execute as: Me
 *    - Who has access: Anyone
 *    - Bấm Deploy, cấp quyền khi được hỏi.
 * 6. Copy URL dạng https://script.google.com/macros/s/XXXX/exec — đây là VITE_ORDER_WEBHOOK_URL.
 * 7. Nếu đã đặt ORDER_WEBHOOK_TOKEN ở bước 4, dùng đúng giá trị đó làm VITE_ORDER_WEBHOOK_TOKEN
 *    trong cấu hình môi trường của website (xem GOOGLE_SHEETS_SETUP.md).
 *
 * Mỗi khi khách xác nhận thanh toán trên website, một dòng mới sẽ tự động được thêm vào sheet "Orders".
 */

const SHEET_NAME = 'Orders';

const HEADERS = [
  'Thời gian đặt hàng',
  'Mã đơn hàng',
  'Họ và tên',
  'Số điện thoại',
  'Địa chỉ giao hàng',
  'Ghi chú',
  'Phương thức nhận hàng',
  'Khung giờ nhận hàng',
  'Phương thức thanh toán',
  'Danh sách sản phẩm',
  'Tạm tính',
  'Phí giao hàng',
  'Tổng cộng',
  'Trạng thái',
];

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);

    const expectedToken = PropertiesService.getScriptProperties().getProperty('ORDER_WEBHOOK_TOKEN');
    if (expectedToken && data.token !== expectedToken) {
      return jsonResponse({ ok: false, error: 'unauthorized' });
    }

    const sheet = getOrCreateSheet();
    const itemsText = (data.items || [])
      .map((i) => i.name + ' x' + i.qty)
      .join('; ');

    sheet.appendRow([
      new Date(),
      data.code || '',
      data.name || '',
      data.phone || '',
      data.address || '',
      data.note || '',
      deliveryMethodLabel(data.deliveryMethod),
      data.deliveryTime || '',
      paymentMethodLabel(data.paymentMethod),
      itemsText,
      data.subtotal || 0,
      data.fee || 0,
      data.total || 0,
      'Đã xác nhận',
    ]);

    return jsonResponse({ ok: true });
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err) });
  }
}

// Cho phép mở URL bằng trình duyệt để kiểm tra web app đã deploy đúng chưa.
function doGet() {
  return jsonResponse({ ok: true, message: 'Lò Nếp Mây order webhook đang hoạt động.' });
}

function getOrCreateSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function deliveryMethodLabel(v) {
  if (v === 'delivery') return 'Giao tận nơi';
  if (v === 'pickup') return 'Lấy tại cửa hàng';
  return v || '';
}

function paymentMethodLabel(v) {
  const map = { transfer: 'Chuyển khoản', card: 'Thẻ', ewallet: 'Momo / ZaloPay', cash: 'Tiền mặt' };
  return map[v] || v || '';
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
