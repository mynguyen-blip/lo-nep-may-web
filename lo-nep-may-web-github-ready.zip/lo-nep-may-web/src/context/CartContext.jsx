import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { DELIVERY_FEE, FREE_SHIP_THRESHOLD, findProduct } from '../data/products';
import { useToast } from './ToastContext';

const CartContext = createContext(null);
const STORAGE_KEY = 'lnm_cart';

function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function CartProvider({ children }) {
  const [cart, setCart] = useState(loadCart);
  const { flashToast } = useToast();

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    } catch {
      /* localStorage unavailable — cart just won't persist across reloads */
    }
  }, [cart]);

  const addToCart = useCallback((id, qty = 1) => {
    setCart((prev) => ({ ...prev, [id]: (prev[id] || 0) + qty }));
    flashToast('Đã thêm vào giỏ hàng');
  }, [flashToast]);

  const changeQty = useCallback((id, delta) => {
    setCart((prev) => {
      const next = { ...prev };
      const nextQty = (next[id] || 0) + delta;
      if (nextQty <= 0) delete next[id];
      else next[id] = nextQty;
      return next;
    });
  }, []);

  const removeFromCart = useCallback((id) => {
    setCart((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }, []);

  const clearCart = useCallback(() => setCart({}), []);

  const cartItems = useMemo(() => (
    Object.entries(cart)
      .map(([id, qty]) => {
        const p = findProduct(id);
        if (!p) return null;
        return { ...p, qty, lineTotal: p.price * qty };
      })
      .filter(Boolean)
  ), [cart]);

  const cartCount = useMemo(() => cartItems.reduce((a, i) => a + i.qty, 0), [cartItems]);
  const subtotal = useMemo(() => cartItems.reduce((a, i) => a + i.lineTotal, 0), [cartItems]);
  const fee = subtotal > 0 && subtotal < FREE_SHIP_THRESHOLD ? DELIVERY_FEE : 0;
  const total = subtotal + fee;

  const value = { cartItems, cartCount, subtotal, fee, total, addToCart, changeQty, removeFromCart, clearCart };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
