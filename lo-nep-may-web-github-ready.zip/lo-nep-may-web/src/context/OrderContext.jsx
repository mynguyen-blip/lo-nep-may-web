import { createContext, useCallback, useContext, useState } from 'react';

const OrderContext = createContext(null);
const STORAGE_KEY = 'lnm_order';

function loadOrders() {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : { pendingOrder: null, lastOrder: null };
  } catch {
    return { pendingOrder: null, lastOrder: null };
  }
}

function persist(state) {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* sessionStorage unavailable — order state just won't survive a reload */
  }
}

export function OrderProvider({ children }) {
  const [{ pendingOrder, lastOrder }, setState] = useState(loadOrders);

  const createPendingOrder = useCallback((order) => {
    const code = 'LNM' + Math.floor(100000 + Math.random() * 900000);
    const next = { pendingOrder: { ...order, code }, lastOrder };
    setState(next);
    persist(next);
    return next.pendingOrder;
  }, [lastOrder]);

  const confirmPendingOrder = useCallback(() => {
    const next = { pendingOrder: null, lastOrder: pendingOrder };
    setState(next);
    persist(next);
  }, [pendingOrder]);

  const value = { pendingOrder, lastOrder, createPendingOrder, confirmPendingOrder };

  return <OrderContext.Provider value={value}>{children}</OrderContext.Provider>;
}

export function useOrder() {
  const ctx = useContext(OrderContext);
  if (!ctx) throw new Error('useOrder must be used within OrderProvider');
  return ctx;
}
