import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Collection from './pages/Collection';
import About from './pages/About';
import Blog from './pages/Blog';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import QrPay from './pages/QrPay';
import Confirm from './pages/Confirm';
import { ToastProvider } from './context/ToastContext';
import { CartProvider } from './context/CartContext';
import { OrderProvider } from './context/OrderContext';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function Layout({ children }) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />
      <main style={{ flex: 1 }}>{children}</main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <CartProvider>
        <OrderProvider>
          <BrowserRouter>
            <ScrollToTop />
            <Layout>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/bo-suu-tap" element={<Collection />} />
                <Route path="/ve-chung-toi" element={<About />} />
                <Route path="/blog" element={<Blog />} />
                <Route path="/gio-hang" element={<Cart />} />
                <Route path="/thanh-toan" element={<Checkout />} />
                <Route path="/thanh-toan/qr" element={<QrPay />} />
                <Route path="/xac-nhan" element={<Confirm />} />
              </Routes>
            </Layout>
          </BrowserRouter>
        </OrderProvider>
      </CartProvider>
    </ToastProvider>
  );
}
