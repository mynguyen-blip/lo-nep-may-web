import { useState } from 'react';

const sizes = {
  sm: { h: 36, fs: 14, px: 14 },
  md: { h: 48, fs: 16, px: 20 },
  lg: { h: 56, fs: 17, px: 24 },
};

const variants = {
  primary: { bg: 'var(--color-primary)', color: 'var(--text-on-primary)', border: 'none', hoverBg: 'var(--color-primary-hover)' },
  accent: { bg: 'var(--color-accent)', color: 'var(--text-on-accent)', border: 'none', hoverBg: 'var(--color-accent-hover)' },
  secondary: { bg: 'var(--surface-card)', color: 'var(--color-primary)', border: '1px solid var(--border-strong)', hoverBg: 'var(--color-primary-subtle)' },
  ghost: { bg: 'transparent', color: 'var(--color-primary)', border: 'none', hoverBg: 'var(--color-primary-subtle)' },
};

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  disabled = false,
  loading = false,
  fullWidth = false,
  type = 'button',
  onClick,
  style,
}) {
  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;
  const [hover, setHover] = useState(false);

  return (
    <button
      type={type}
      onClick={disabled || loading ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      disabled={disabled || loading}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        height: s.h,
        padding: `0 ${s.px}px`,
        fontSize: s.fs,
        fontWeight: 'var(--fw-button)',
        fontFamily: 'var(--font-base)',
        background: disabled ? 'var(--neutral-200)' : hover ? v.hoverBg : v.bg,
        color: disabled ? 'var(--text-disabled)' : v.color,
        border: v.border,
        borderRadius: 'var(--radius-md)',
        cursor: disabled || loading ? 'not-allowed' : 'pointer',
        width: fullWidth ? '100%' : 'auto',
        transition: 'background var(--duration-fast) var(--ease-standard)',
        opacity: loading ? 0.7 : 1,
        ...style,
      }}
    >
      {loading ? 'Đang xử lý…' : icon ? (
        <span style={{ display: 'inline-flex', fontSize: s.fs + 2 }}>{icon}</span>
      ) : null}
      {!loading && children}
    </button>
  );
}
