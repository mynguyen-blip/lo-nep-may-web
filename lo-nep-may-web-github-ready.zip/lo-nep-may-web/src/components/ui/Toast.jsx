export default function Toast({ message, visible }) {
  if (!visible) return null;
  return (
    <div
      style={{
        position: 'fixed',
        bottom: 24,
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 100,
        background: 'var(--brown-700)',
        color: '#fff',
        padding: '12px 22px',
        borderRadius: 'var(--radius-md)',
        boxShadow: 'var(--shadow-md)',
        fontSize: 'var(--fs-body)',
        fontFamily: 'var(--font-base)',
      }}
    >
      {message}
    </div>
  );
}
