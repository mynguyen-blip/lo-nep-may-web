import { useState } from 'react';

export default function IconButton({ icon, size = 44, variant = 'ghost', onClick, ariaLabel }) {
  const [hover, setHover] = useState(false);
  const bg = variant === 'filled' ? 'var(--color-primary)' : hover ? 'var(--surface-sunken)' : 'transparent';
  const color = variant === 'filled' ? 'var(--text-on-primary)' : 'var(--text-primary)';

  return (
    <button
      type="button"
      aria-label={ariaLabel}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        width: size,
        height: size,
        minWidth: 44,
        minHeight: 44,
        borderRadius: 'var(--radius-full)',
        border: 'none',
        background: bg,
        color,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: size * 0.5,
        cursor: 'pointer',
        transition: 'background var(--duration-fast) var(--ease-standard)',
      }}
    >
      {icon}
    </button>
  );
}
