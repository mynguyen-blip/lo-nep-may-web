import { useState } from 'react';

export default function Input({ label, placeholder, value, onChange, helper, error, icon, type = 'text' }) {
  const [focus, setFocus] = useState(false);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, width: '100%' }}>
      {label && (
        <label style={{ fontSize: 'var(--fs-caption)', fontWeight: 600, color: 'var(--text-secondary)' }}>
          {label}
        </label>
      )}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          height: 'var(--touch-target-min)',
          padding: '0 16px',
          border: `1.5px solid ${error ? 'var(--color-danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)'}`,
          borderRadius: 'var(--radius-md)',
          background: 'var(--surface-card)',
          boxShadow: focus ? 'var(--focus-ring)' : 'none',
          transition: 'box-shadow var(--duration-fast) var(--ease-standard)',
        }}
      >
        {icon && <span style={{ color: 'var(--text-tertiary)', fontSize: 18 }}>{icon}</span>}
        <input
          type={type}
          value={value}
          placeholder={placeholder}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          onChange={(e) => onChange && onChange(e.target.value)}
          style={{
            border: 'none',
            outline: 'none',
            width: '100%',
            fontSize: 'var(--fs-body-lg)',
            fontFamily: 'var(--font-base)',
            background: 'transparent',
            color: 'var(--text-primary)',
          }}
        />
      </div>
      {(helper || error) && (
        <span style={{ fontSize: 'var(--fs-caption)', color: error ? 'var(--color-danger)' : 'var(--text-tertiary)' }}>
          {error || helper}
        </span>
      )}
    </div>
  );
}
