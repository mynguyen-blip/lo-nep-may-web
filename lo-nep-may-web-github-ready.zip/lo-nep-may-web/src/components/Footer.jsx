export default function Footer() {
  return (
    <footer style={{ background: 'var(--brown-700)', color: '#F4E9DC', marginTop: 'auto' }}>
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '40px 24px',
          display: 'flex',
          flexWrap: 'wrap',
          gap: 32,
          justifyContent: 'space-between',
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 280 }}>
          <div style={{ background: 'var(--brown-50)', borderRadius: 'var(--radius-md)', padding: '8px 14px', display: 'inline-flex', width: 'fit-content' }}>
            <img src="/images/logo.png" alt="Lò Nếp Mây" style={{ height: 56, width: 'auto', display: 'block' }} />
          </div>
          <p style={{ fontSize: 'var(--fs-caption)', color: '#D9C4AE', margin: 0, lineHeight: 'var(--lh-caption)' }}>
            Bánh thủ công, làm mới mỗi ngày.
          </p>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 'var(--fs-caption)', color: '#D9C4AE' }}>
          <div style={{ fontWeight: 700, color: '#fff', marginBottom: 4 }}>Liên hệ</div>
          <div>123 Nguyễn Văn Trỗi, Quận Phú Nhuận, TP.HCM</div>
          <div>Hotline: 090 123 4567</div>
          <div>Giờ mở cửa: 7:00 – 21:00 hàng ngày</div>
          <div>Facebook / Instagram: @lo.nep.may</div>
        </div>
      </div>
      <div style={{ textAlign: 'center', fontSize: 12, color: '#B99C7C', padding: '16px 24px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
        © 2026 Lò Nếp Mây. Bản demo prototype.
      </div>
    </footer>
  );
}
