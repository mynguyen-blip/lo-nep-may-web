import { formatVnd } from '../data/products';

export default function ProductCard({ product, onAdd }) {
  return (
    <div
      style={{
        background: 'var(--surface-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
      }}
    >
      <img
        src={product.img}
        alt={product.name}
        style={{ width: '100%', aspectRatio: '4/3', objectFit: 'cover', display: 'block' }}
      />
      <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10, flex: 1 }}>
        <h3
          style={{
            fontSize: 'var(--fs-h3)',
            fontWeight: 'var(--fw-h3)',
            lineHeight: 'var(--lh-h3)',
            margin: 0,
            color: 'var(--text-primary)',
            fontFamily: 'var(--font-base)',
          }}
        >
          {product.name}
        </h3>
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          <span style={{ fontSize: 'var(--fs-body-lg)', fontWeight: 700, color: 'var(--color-primary)', fontFamily: 'var(--font-base)' }}>
            {formatVnd(product.price)}
          </span>
          <button
            onClick={() => onAdd(product.id)}
            style={{
              height: 40,
              padding: '0 16px',
              borderRadius: 'var(--radius-md)',
              border: 'none',
              background: 'var(--color-accent)',
              color: '#fff',
              fontWeight: 600,
              fontSize: 14,
              fontFamily: 'var(--font-base)',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
            }}
          >
            Thêm vào giỏ
          </button>
        </div>
      </div>
    </div>
  );
}
