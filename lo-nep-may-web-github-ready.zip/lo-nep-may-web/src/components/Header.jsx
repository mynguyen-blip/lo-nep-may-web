import { NavLink, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';

const NAV_ITEMS = [
  { to: '/', label: 'Trang chủ', end: true },
  { to: '/bo-suu-tap', label: 'Bộ sưu tập' },
  { to: '/ve-chung-toi', label: 'Về chúng tôi' },
  { to: '/blog', label: 'Blog' },
];

const navLinkStyle = ({ isActive }) => ({
  padding: '10px 14px',
  background: isActive ? 'var(--color-accent-subtle)' : 'none',
  border: 'none',
  cursor: 'pointer',
  fontFamily: 'var(--font-base)',
  fontSize: 15,
  borderRadius: 'var(--radius-md)',
  whiteSpace: 'nowrap',
  color: isActive ? 'var(--color-accent)' : 'var(--text-secondary)',
  fontWeight: isActive ? 700 : 500,
  textDecoration: 'none',
  display: 'inline-block',
});

export default function Header() {
  const { cartCount } = useCart();
  const { flashToast } = useToast();
  const navigate = useNavigate();

  return (
    <header
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 50,
        background: 'var(--surface-card)',
        borderBottom: '1px solid var(--border-default)',
      }}
    >
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '12px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 20,
          flexWrap: 'wrap',
        }}
      >
        <button
          onClick={() => navigate('/')}
          style={{ display: 'flex', alignItems: 'center', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
        >
          <img src="/images/logo.png" alt="Lò Nếp Mây" style={{ height: 52, width: 'auto', display: 'block' }} />
        </button>

        <nav style={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          {NAV_ITEMS.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} style={navLinkStyle}>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ display: 'flex', gap: 6, fontSize: 13, fontFamily: 'var(--font-base)' }}>
            <span style={{ fontWeight: 700, color: 'var(--color-accent)', cursor: 'default' }}>VI</span>
            <span style={{ color: 'var(--border-strong)' }}>/</span>
            <button
              onClick={() => flashToast('Phiên bản tiếng Anh đang được phát triển')}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', fontWeight: 600, fontSize: 13, fontFamily: 'var(--font-base)', padding: 0 }}
            >
              EN
            </button>
          </div>
          <button
            onClick={() => navigate('/gio-hang')}
            aria-label="Giỏ hàng"
            style={{ position: 'relative', background: 'none', border: 'none', cursor: 'pointer', padding: 8, display: 'flex' }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)" strokeWidth="1.8">
              <path d="M6 6h15l-1.5 9h-12z" />
              <path d="M6 6L4 3H2" />
              <circle cx="9" cy="20" r="1.4" fill="var(--color-primary)" />
              <circle cx="18" cy="20" r="1.4" fill="var(--color-primary)" />
            </svg>
            {cartCount > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: 0,
                  right: 0,
                  background: 'var(--color-accent)',
                  color: '#fff',
                  fontSize: 11,
                  fontWeight: 700,
                  minWidth: 18,
                  height: 18,
                  borderRadius: 999,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '0 4px',
                }}
              >
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
