export const CATEGORIES = ['Bánh kem', 'Bánh mì & Bánh ngọt', 'Donut'];

export const PRODUCTS = [
  { id: 'p01', name: 'Bánh kem hoa tươi', price: 850000, img: '/images/banh-01.jpg', category: 'Bánh kem' },
  { id: 'p02', name: 'Croissant bơ Pháp (set 2 cái)', price: 89000, img: '/images/banh-02.jpg', category: 'Bánh mì & Bánh ngọt' },
  { id: 'p03', name: 'Bánh kem hoa hồng phấn', price: 780000, img: '/images/banh-03.jpg', category: 'Bánh kem' },
  { id: 'p04', name: 'Bánh kem quả mọng phủ kem tươi', price: 690000, img: '/images/banh-04.jpg', category: 'Bánh kem' },
  { id: 'p05', name: 'Bánh chocolate drip cookies & cream', price: 920000, img: '/images/banh-05.jpg', category: 'Bánh kem' },
  { id: 'p06', name: 'Bánh mì bơ nướng thơm (set 3 ổ)', price: 65000, img: '/images/banh-06.jpg', category: 'Bánh mì & Bánh ngọt' },
  { id: 'p07', name: 'Donut phủ đường màu', price: 35000, img: '/images/banh-07.jpg', category: 'Donut' },
  { id: 'p08', name: 'Bánh chocolate mousse trái cây', price: 950000, img: '/images/banh-08.jpg', category: 'Bánh kem' },
  { id: 'p09', name: 'Bánh tầng nhiều hương vị (rainbow layer)', price: 1250000, img: '/images/banh-09.jpg', category: 'Bánh kem' },
  { id: 'p10', name: 'Bánh kem vani cổ điển hoa tươi', price: 820000, img: '/images/banh-10.jpg', category: 'Bánh kem' },
];

export const TIME_SLOTS = ['Giao ngay', '11:00 - 12:00', '12:00 - 13:00', '17:00 - 18:00', '18:00 - 19:00', '19:00 - 20:00'];

export const FREE_SHIP_THRESHOLD = 500000;
export const DELIVERY_FEE = 20000;

export function formatVnd(n) {
  return n.toLocaleString('vi-VN') + 'đ';
}

export function findProduct(id) {
  return PRODUCTS.find((p) => p.id === id);
}
