import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import ProductCard from '../components/ProductCard';
import { CATEGORIES, PRODUCTS } from '../data/products';
import { useCart } from '../context/CartContext';

export default function Home() {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const homeGroups = CATEGORIES.map((cat) => ({ name: cat, items: PRODUCTS.filter((p) => p.category === cat) }));

  return (
    <div>
      <div
        style={{
          position: 'relative',
          height: 440,
          backgroundImage: "url('/images/banh-08.jpg')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(43,24,16,0.75), rgba(43,24,16,0.25))' }} />
        <div style={{ position: 'relative', maxWidth: 1200, margin: '0 auto', padding: '0 24px', width: '100%' }}>
          <div style={{ maxWidth: 520 }}>
            <h1 style={{ fontSize: 40, lineHeight: 1.15, fontWeight: 800, color: '#fff', margin: '0 0 16px', fontFamily: 'var(--font-base)' }}>
              Bánh thủ công, làm mới mỗi ngày
            </h1>
            <p style={{ fontSize: 'var(--fs-body-lg)', lineHeight: 'var(--lh-body-lg)', color: '#F4E9DC', margin: '0 0 28px' }}>
              Lò Nếp Mây gửi đến bạn những chiếc bánh kem, bánh mì và bánh ngọt được làm tay từ nguyên liệu tự nhiên.
            </p>
            <Button variant="accent" size="lg" onClick={() => navigate('/bo-suu-tap')} style={{ minWidth: 220 }}>
              Xem bộ sưu tập
            </Button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '48px 24px', display: 'flex', flexDirection: 'column', gap: 48 }}>
        {homeGroups.map((group) => (
          <div key={group.name}>
            <h2 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: '0 0 20px', fontFamily: 'var(--font-base)' }}>
              {group.name}
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: 20 }}>
              {group.items.map((p) => (
                <ProductCard key={p.id} product={p} onAdd={addToCart} />
              ))}
            </div>
          </div>
        ))}
      </div>

      <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 40 }}>
        <Button variant="accent" size="lg" onClick={() => navigate('/gio-hang')} style={{ minWidth: 220 }}>
          Đặt hàng ngay
        </Button>
      </div>
    </div>
  );
}
