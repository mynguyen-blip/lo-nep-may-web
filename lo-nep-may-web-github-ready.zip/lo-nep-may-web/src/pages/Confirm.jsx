import { Navigate, useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import { formatVnd } from '../data/products';
import { useOrder } from '../context/OrderContext';

export default function Confirm() {
  const navigate = useNavigate();
  const { lastOrder } = useOrder();

  if (!lastOrder) {
    return <Navigate to="/" replace />;
  }

  const estimateText = lastOrder.deliveryTime === 'Giao ngay'
    ? (lastOrder.deliveryMethod === 'pickup' ? 'Bánh sẽ sẵn sàng để lấy trong khoảng 45 phút.' : 'Đơn hàng sẽ được giao ngay, dự kiến trong 45–60 phút.')
    : (lastOrder.deliveryMethod === 'pickup' ? `Vui lòng đến lấy bánh vào khung giờ: ${lastOrder.deliveryTime}.` : `Đơn hàng sẽ được giao vào khung giờ: ${lastOrder.deliveryTime}.`);

  return (
    <div style={{ maxWidth: 640, margin: '0 auto', padding: '60px 24px', textAlign: 'center' }}>
      <div
        style={{
          width: 72,
          height: 72,
          borderRadius: 999,
          background: 'var(--color-success-bg)',
          color: 'var(--color-success-text)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 36,
          margin: '0 auto 24px',
        }}
      >
        ✓
      </div>
      <h1 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: '0 0 8px', fontFamily: 'var(--font-base)' }}>
        Đặt hàng thành công!
      </h1>
      <p style={{ color: 'var(--text-secondary)', fontSize: 'var(--fs-body-lg)', margin: '0 0 32px' }}>
        Mã đơn hàng của bạn là <strong style={{ color: 'var(--color-accent)' }}>{lastOrder.code}</strong>
      </p>
      <div style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', padding: 20, textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 24 }}>
        {lastOrder.items.map((item) => (
          <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-body)', color: 'var(--text-secondary)' }}>
            <span>{item.name} × {item.qty}</span>
            <span>{formatVnd(item.lineTotal)}</span>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-h3)', fontWeight: 700, color: 'var(--color-primary)', paddingTop: 10, borderTop: '1px solid var(--border-default)' }}>
          <span>Tổng cộng</span><span>{formatVnd(lastOrder.total)}</span>
        </div>
      </div>
      <p style={{ color: 'var(--text-primary)', fontSize: 'var(--fs-body)', margin: '0 0 32px' }}>{estimateText}</p>
      <Button variant="accent" size="lg" onClick={() => navigate('/')} style={{ minWidth: 180 }}>
        Về trang chủ
      </Button>
    </div>
  );
}
