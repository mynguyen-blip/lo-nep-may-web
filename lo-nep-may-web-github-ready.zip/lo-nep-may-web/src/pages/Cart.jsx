import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import IconButton from '../components/ui/IconButton';
import { formatVnd } from '../data/products';
import { useCart } from '../context/CartContext';

export default function Cart() {
  const navigate = useNavigate();
  const { cartItems, subtotal, fee, total, changeQty, removeFromCart } = useCart();
  const isEmpty = cartItems.length === 0;

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 24px' }}>
      <h1 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: '0 0 24px', fontFamily: 'var(--font-base)' }}>
        Giỏ hàng
      </h1>

      {isEmpty ? (
        <div style={{ textAlign: 'center', padding: '60px 0' }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: 'var(--fs-body-lg)', margin: '0 0 20px' }}>
            Giỏ hàng của bạn đang trống.
          </p>
          <Button variant="accent" onClick={() => navigate('/bo-suu-tap')} style={{ minWidth: 180 }}>
            Xem bộ sưu tập
          </Button>
        </div>
      ) : (
        <div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {cartItems.map((item) => (
              <div key={item.id} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 0', borderBottom: '1px solid var(--border-default)' }}>
                <img src={item.img} alt={item.name} style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 'var(--radius-md)', flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: 'var(--fs-body)', marginBottom: 4 }}>{item.name}</div>
                  <div style={{ color: 'var(--text-tertiary)', fontSize: 'var(--fs-caption)' }}>{formatVnd(item.price)} / cái</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <IconButton icon="−" size={36} ariaLabel="Giảm" onClick={() => changeQty(item.id, -1)} />
                  <span style={{ minWidth: 20, textAlign: 'center', fontWeight: 600 }}>{item.qty}</span>
                  <IconButton icon="+" size={36} ariaLabel="Tăng" onClick={() => changeQty(item.id, 1)} />
                </div>
                <div style={{ width: 100, textAlign: 'right', fontWeight: 700, color: 'var(--color-primary)' }}>{formatVnd(item.lineTotal)}</div>
                <button
                  onClick={() => removeFromCart(item.id)}
                  aria-label="Xóa"
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', fontSize: 20, padding: '4px 8px' }}
                >
                  ×
                </button>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 24, padding: 20, background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-body)', color: 'var(--text-secondary)' }}>
              <span>Tạm tính</span><span>{formatVnd(subtotal)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-body)', color: 'var(--text-secondary)' }}>
              <span>Phí giao hàng</span><span>{fee === 0 ? 'Miễn phí' : formatVnd(fee)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-h3)', fontWeight: 700, color: 'var(--color-primary)', paddingTop: 10, borderTop: '1px solid var(--border-default)' }}>
              <span>Tổng cộng</span><span>{formatVnd(total)}</span>
            </div>
            <div style={{ marginTop: 8 }}>
              <Button variant="accent" size="lg" fullWidth onClick={() => navigate('/thanh-toan')}>
                Tiến hành thanh toán
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
