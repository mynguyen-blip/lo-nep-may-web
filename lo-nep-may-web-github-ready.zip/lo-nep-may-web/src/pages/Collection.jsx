import { useState } from 'react';
import ProductCard from '../components/ProductCard';
import { CATEGORIES, PRODUCTS } from '../data/products';
import { useCart } from '../context/CartContext';

const ALL = 'all';

export default function Collection() {
  const [filter, setFilter] = useState(ALL);
  const { addToCart } = useCart();
  const chips = [ALL, ...CATEGORIES];
  const filtered = filter === ALL ? PRODUCTS : PRODUCTS.filter((p) => p.category === filter);

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '40px 24px' }}>
      <h1 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: '0 0 24px', fontFamily: 'var(--font-base)' }}>
        Bộ sưu tập
      </h1>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 28 }}>
        {chips.map((c) => {
          const selected = filter === c;
          return (
            <button
              key={c}
              onClick={() => setFilter(c)}
              style={{
                height: 40,
                padding: '0 18px',
                borderRadius: 'var(--radius-full)',
                cursor: 'pointer',
                fontFamily: 'var(--font-base)',
                fontSize: 15,
                whiteSpace: 'nowrap',
                border: selected ? '1.5px solid var(--color-accent)' : '1.5px solid var(--border-default)',
                background: selected ? 'var(--color-accent-subtle)' : 'var(--surface-card)',
                color: selected ? 'var(--color-accent)' : 'var(--text-primary)',
                fontWeight: selected ? 600 : 400,
              }}
            >
              {c === ALL ? 'Tất cả' : c}
            </button>
          );
        })}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: 20 }}>
        {filtered.map((p) => (
          <ProductCard key={p.id} product={p} onAdd={addToCart} />
        ))}
      </div>
    </div>
  );
}
