import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { formatVnd, TIME_SLOTS } from '../data/products';
import { useCart } from '../context/CartContext';
import { useOrder } from '../context/OrderContext';
import { useToast } from '../context/ToastContext';

const DELIVERY_OPTIONS = [
  { value: 'delivery', label: 'Giao tận nơi' },
  { value: 'pickup', label: 'Lấy tại cửa hàng' },
];

const PAYMENT_OPTIONS = [
  { value: 'transfer', label: 'Chuyển khoản' },
  { value: 'card', label: 'Thẻ' },
  { value: 'ewallet', label: 'Momo / ZaloPay' },
  { value: 'cash', label: 'Tiền mặt' },
];

const radioLabelStyle = {
  display: 'flex',
  alignItems: 'center',
  gap: 10,
  padding: '12px 14px',
  border: '1.5px solid var(--border-default)',
  borderRadius: 'var(--radius-md)',
  cursor: 'pointer',
  marginBottom: 8,
  background: 'var(--surface-card)',
};

export default function Checkout() {
  const navigate = useNavigate();
  const { cartItems, subtotal, fee, total } = useCart();
  const { createPendingOrder } = useOrder();
  const { flashToast } = useToast();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [note, setNote] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState('delivery');
  const [paymentMethod, setPaymentMethod] = useState('transfer');
  const [deliveryTime, setDeliveryTime] = useState('Giao ngay');

  const showAddressField = deliveryMethod === 'delivery';

  const handlePlaceOrder = () => {
    if (cartItems.length === 0) {
      flashToast('Giỏ hàng đang trống');
      return;
    }
    if (!name.trim() || !phone.trim() || (showAddressField && !address.trim())) {
      flashToast('Vui lòng điền đầy đủ thông tin giao hàng');
      return;
    }
    createPendingOrder({
      items: cartItems,
      subtotal,
      fee,
      total,
      name,
      phone,
      address,
      note,
      deliveryMethod,
      paymentMethod,
      deliveryTime,
    });
    navigate('/thanh-toan/qr');
  };

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 24px', display: 'flex', gap: 32, flexWrap: 'wrap', alignItems: 'flex-start' }}>
      <div style={{ flex: 2, minWidth: 320, display: 'flex', flexDirection: 'column', gap: 20 }}>
        <h1 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: 0, fontFamily: 'var(--font-base)' }}>
          Thanh toán
        </h1>
        <Input label="Họ và tên" placeholder="Nguyễn Văn A" value={name} onChange={setName} />
        <Input label="Số điện thoại" placeholder="090 000 0000" value={phone} onChange={setPhone} />
        {showAddressField && (
          <Input label="Địa chỉ giao hàng" placeholder="Số nhà, đường, quận" value={address} onChange={setAddress} />
        )}
        <Input label="Ghi chú đơn hàng" placeholder="VD: viết chữ trên bánh, giờ nhận..." value={note} onChange={setNote} />

        <div>
          <div style={{ fontSize: 'var(--fs-caption)', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8 }}>
            Phương thức nhận hàng
          </div>
          {DELIVERY_OPTIONS.map((opt) => (
            <label key={opt.value} style={radioLabelStyle}>
              <input
                type="radio"
                name="deliveryMethod"
                checked={deliveryMethod === opt.value}
                onChange={() => setDeliveryMethod(opt.value)}
                style={{ width: 18, height: 18, accentColor: 'var(--color-accent)' }}
              />
              <span style={{ fontSize: 'var(--fs-body)', color: 'var(--text-primary)' }}>{opt.label}</span>
            </label>
          ))}
        </div>

        <div>
          <div style={{ fontSize: 'var(--fs-caption)', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8 }}>
            Khung giờ nhận hàng
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {TIME_SLOTS.map((t) => {
              const selected = deliveryTime === t;
              return (
                <button
                  key={t}
                  onClick={() => setDeliveryTime(t)}
                  style={{
                    height: 40,
                    padding: '0 16px',
                    borderRadius: 'var(--radius-full)',
                    cursor: 'pointer',
                    fontFamily: 'var(--font-base)',
                    fontSize: 14,
                    whiteSpace: 'nowrap',
                    border: selected ? '1.5px solid var(--color-accent)' : '1.5px solid var(--border-default)',
                    background: selected ? 'var(--color-accent-subtle)' : 'var(--surface-card)',
                    color: selected ? 'var(--color-accent)' : 'var(--text-primary)',
                    fontWeight: selected ? 600 : 400,
                  }}
                >
                  {t}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <div style={{ fontSize: 'var(--fs-caption)', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8 }}>
            Phương thức thanh toán
          </div>
          {PAYMENT_OPTIONS.map((opt) => (
            <label key={opt.value} style={radioLabelStyle}>
              <input
                type="radio"
                name="paymentMethod"
                checked={paymentMethod === opt.value}
                onChange={() => setPaymentMethod(opt.value)}
                style={{ width: 18, height: 18, accentColor: 'var(--color-accent)' }}
              />
              <span style={{ fontSize: 'var(--fs-body)', color: 'var(--text-primary)' }}>{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div
        style={{
          flex: 1,
          minWidth: 280,
          position: 'sticky',
          top: 88,
          background: 'var(--surface-card)',
          border: '1px solid var(--border-default)',
          borderRadius: 'var(--radius-lg)',
          padding: 20,
          display: 'flex',
          flexDirection: 'column',
          gap: 12,
        }}
      >
        <h3 style={{ fontSize: 'var(--fs-h3)', fontWeight: 'var(--fw-h3)', color: 'var(--color-primary)', margin: 0, fontFamily: 'var(--font-base)' }}>
          Tóm tắt đơn hàng
        </h3>
        {cartItems.map((item) => (
          <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-caption)', color: 'var(--text-secondary)' }}>
            <span>{item.name} × {item.qty}</span>
            <span>{formatVnd(item.lineTotal)}</span>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-body)', color: 'var(--text-secondary)', paddingTop: 8, borderTop: '1px solid var(--border-default)' }}>
          <span>Tạm tính</span><span>{formatVnd(subtotal)}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-body)', color: 'var(--text-secondary)' }}>
          <span>Phí giao hàng</span><span>{fee === 0 ? 'Miễn phí' : formatVnd(fee)}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-h3)', fontWeight: 700, color: 'var(--color-primary)', paddingTop: 8, borderTop: '1px solid var(--border-default)' }}>
          <span>Tổng cộng</span><span>{formatVnd(total)}</span>
        </div>
        <Button variant="accent" size="lg" fullWidth onClick={handlePlaceOrder}>
          Đặt hàng
        </Button>
      </div>
    </div>
  );
}
