const BLOG_POSTS = [
  { img: '/images/banh-02.jpg', title: 'Bí quyết lớp vỏ croissant giòn tan', excerpt: 'Điều gì làm nên lớp vỏ giòn xốp nhiều tầng của một chiếc croissant ngon — tất cả nằm ở kỹ thuật gấp bột và nhiệt độ lò.' },
  { img: '/images/banh-06.jpg', title: 'Vì sao bánh mì handmade luôn ngon hơn', excerpt: 'Thời gian ủ bột chậm và men tự nhiên tạo nên hương vị mà bánh mì công nghiệp khó có được.' },
  { img: '/images/banh-09.jpg', title: 'Đằng sau một chiếc bánh nhiều tầng', excerpt: 'Một chiếc bánh rainbow layer cần hơn một ngày để hoàn thiện — từ nướng cốt bánh đến xếp tầng và trang trí.' },
];

export default function Blog() {
  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 24px' }}>
      <h1 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: '0 0 24px', fontFamily: 'var(--font-base)' }}>
        Blog
      </h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))', gap: 24 }}>
        {BLOG_POSTS.map((post) => (
          <div key={post.title} style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
            <img src={post.img} alt={post.title} style={{ width: '100%', aspectRatio: '16/10', objectFit: 'cover', display: 'block' }} />
            <div style={{ padding: 18 }}>
              <h3 style={{ fontSize: 'var(--fs-h3)', fontWeight: 'var(--fw-h3)', color: 'var(--text-primary)', margin: '0 0 8px', fontFamily: 'var(--font-base)' }}>
                {post.title}
              </h3>
              <p style={{ fontSize: 'var(--fs-body)', color: 'var(--text-secondary)', margin: 0, lineHeight: 'var(--lh-body)' }}>{post.excerpt}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
