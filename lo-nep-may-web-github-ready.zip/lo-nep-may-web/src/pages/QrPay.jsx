import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import { formatVnd } from '../data/products';
import { useOrder } from '../context/OrderContext';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';
import { submitOrderToSheet } from '../lib/orderSheet';

const PAYMENT_METHOD_LABELS = {
  transfer: 'Chuyển khoản',
  card: 'Thẻ',
  ewallet: 'Momo / ZaloPay',
  cash: 'Tiền mặt',
};

export default function QrPay() {
  const navigate = useNavigate();
  const { pendingOrder, confirmPendingOrder } = useOrder();
  const { clearCart } = useCart();
  const { flashToast } = useToast();
  // Captured once at mount: confirming payment nulls out pendingOrder in
  // context, and re-reading it live here would race the "no order" redirect
  // below against the navigate to the confirmation page.
  const [order] = useState(pendingOrder);

  useEffect(() => {
    if (!order) navigate('/gio-hang', { replace: true });
  }, [order, navigate]);

  if (!order) return null;

  const qrData = [
    'LO NEP MAY',
    `Ma don: ${order.code}`,
    `So tien: ${order.total} VND`,
    `SL san pham: ${order.items.reduce((a, i) => a + i.qty, 0)}`,
    `Noi dung CK: ${order.code}`,
  ].join('\n');
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=8&data=${encodeURIComponent(qrData)}`;

  const handleConfirm = () => {
    confirmPendingOrder();
    clearCart();
    submitOrderToSheet(order).then((res) => {
      if (!res.ok && !res.skipped) {
        flashToast('Đơn hàng đã xác nhận nhưng chưa lưu được vào hệ thống quản lý, vui lòng liên hệ cửa hàng.');
      }
    });
    navigate('/xac-nhan');
  };

  return (
    <div style={{ maxWidth: 440, margin: '0 auto', padding: '60px 24px', textAlign: 'center' }}>
      <h1 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: '0 0 8px', fontFamily: 'var(--font-base)' }}>
        Quét mã để thanh toán
      </h1>
      <p style={{ color: 'var(--text-secondary)', fontSize: 'var(--fs-body)', margin: '0 0 24px' }}>
        Phương thức: <strong style={{ color: 'var(--text-primary)' }}>{PAYMENT_METHOD_LABELS[order.paymentMethod] || ''}</strong>
      </p>
      <div style={{ width: 260, height: 260, margin: '0 auto 20px', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', background: '#fff' }}>
        <img src={qrCodeUrl} alt="Mã QR thanh toán" style={{ width: '100%', height: '100%', display: 'block' }} />
      </div>
      <div style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', padding: 16, marginBottom: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-body)', color: 'var(--text-secondary)', marginBottom: 6 }}>
          <span>Mã đơn hàng</span><span style={{ fontWeight: 700, color: 'var(--color-accent)' }}>{order.code}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--fs-h3)', fontWeight: 700, color: 'var(--color-primary)' }}>
          <span>Số tiền</span><span>{formatVnd(order.total)}</span>
        </div>
      </div>
      <p style={{ color: 'var(--text-tertiary)', fontSize: 'var(--fs-caption)', margin: '0 0 24px' }}>
        Mã QR chứa sẵn mã đơn và số tiền chính xác để tránh chuyển nhầm. Khi kết nối tài khoản ngân hàng thật, mã sẽ tự động
        điền số tiền vào app ngân hàng của khách.
      </p>
      <Button variant="accent" size="lg" fullWidth onClick={handleConfirm}>
        Đã thanh toán, xác nhận đơn hàng
      </Button>
    </div>
  );
}
