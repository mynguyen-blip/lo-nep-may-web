const CORE_VALUES = [
  { title: 'Nguyên liệu tự nhiên', desc: 'Bơ, trứng, sữa và trái cây tươi được chọn kỹ mỗi ngày, không dùng chất bảo quản.' },
  { title: 'Làm mới mỗi ngày', desc: 'Mỗi mẻ bánh được nướng trong ngày, không để bánh qua đêm sang ngày sau.' },
  { title: 'Tận tâm với từng chiếc bánh', desc: 'Từng chiếc bánh được hoàn thiện thủ công, từ khâu trộn bột đến trang trí.' },
];

export default function About() {
  return (
    <div style={{ maxWidth: 1000, margin: '0 auto', padding: '40px 24px' }}>
      <h1 style={{ fontSize: 'var(--fs-h1)', fontWeight: 'var(--fw-h1)', color: 'var(--color-primary)', margin: '0 0 24px', fontFamily: 'var(--font-base)' }}>
        Về chúng tôi
      </h1>
      <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap', alignItems: 'flex-start', marginBottom: 36 }}>
        <div style={{ flex: 1, minWidth: 280, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <p style={{ fontSize: 'var(--fs-body-lg)', lineHeight: 'var(--lh-body-lg)', color: 'var(--text-primary)', margin: 0 }}>
            Lò Nếp Mây bắt đầu từ một căn bếp nhỏ, nơi những mẻ bánh đầu tiên được nướng cho gia đình và bạn bè. Từ tình yêu với
            bột, men và hương thơm lúc bánh chín, chúng tôi mở lò để chia sẻ điều đó với nhiều người hơn.
          </p>
          <p style={{ fontSize: 'var(--fs-body-lg)', lineHeight: 'var(--lh-body-lg)', color: 'var(--text-primary)', margin: 0 }}>
            Mỗi ngày, lò của chúng tôi làm mới toàn bộ bánh kem, bánh mì và bánh ngọt — không có mẻ nào để qua ngày sau. Chúng
            tôi tin một chiếc bánh ngon bắt đầu từ nguyên liệu thật và thời gian đủ để lên men, ủ bột đúng cách.
          </p>
        </div>
        <div style={{ flex: 1, minWidth: 240, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <img src="/images/banh-06.jpg" alt="Không gian lò bánh" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 'var(--radius-lg)', aspectRatio: '1/1' }} />
          <img src="/images/banh-01.jpg" alt="Bánh tại Lò Nếp Mây" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 'var(--radius-lg)', aspectRatio: '1/1' }} />
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 20 }}>
        {CORE_VALUES.map((v) => (
          <div key={v.title} style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', padding: 24 }}>
            <h3 style={{ fontSize: 'var(--fs-h3)', fontWeight: 'var(--fw-h3)', color: 'var(--color-accent)', margin: '0 0 8px', fontFamily: 'var(--font-base)' }}>
              {v.title}
            </h3>
            <p style={{ fontSize: 'var(--fs-body)', color: 'var(--text-secondary)', margin: 0, lineHeight: 'var(--lh-body)' }}>{v.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
